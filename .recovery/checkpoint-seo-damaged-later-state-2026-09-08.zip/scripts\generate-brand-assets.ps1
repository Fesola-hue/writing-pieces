param(
  [Parameter(Mandatory = $true)]
  [string]$SocialSource
)

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing

$projectRoot = Split-Path -Parent $PSScriptRoot
$publicDir = Join-Path $projectRoot 'public'
$portraitPath = Join-Path $publicDir 'aisha-onola.jpeg'

function New-SquareIcon([int]$size, [string]$outputPath) {
  $scale = [Math]::Max(4, [Math]::Ceiling(512 / $size))
  $canvasSize = $size * $scale
  $bitmap = New-Object System.Drawing.Bitmap($canvasSize, $canvasSize)
  $graphics = [System.Drawing.Graphics]::FromImage($bitmap)
  $graphics.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
  $graphics.TextRenderingHint = [System.Drawing.Text.TextRenderingHint]::AntiAliasGridFit
  $graphics.Clear([System.Drawing.ColorTranslator]::FromHtml('#211a18'))
  $burgundy = New-Object System.Drawing.SolidBrush([System.Drawing.ColorTranslator]::FromHtml('#641e2f'))
  $gold = New-Object System.Drawing.SolidBrush([System.Drawing.ColorTranslator]::FromHtml('#d6a632'))
  $graphics.FillRectangle($burgundy, 0, 0, [int]($canvasSize * 0.17), $canvasSize)
  $font = New-Object System.Drawing.Font('Arial', [float]($canvasSize * 0.38), [System.Drawing.FontStyle]::Bold, [System.Drawing.GraphicsUnit]::Pixel)
  $format = New-Object System.Drawing.StringFormat
  $format.Alignment = [System.Drawing.StringAlignment]::Center
  $format.LineAlignment = [System.Drawing.StringAlignment]::Center
  $graphics.DrawString('AO', $font, $gold, (New-Object System.Drawing.RectangleF([float]($canvasSize * 0.13), 0, [float]($canvasSize * 0.87), [float]$canvasSize)), $format)
  $target = New-Object System.Drawing.Bitmap($size, $size)
  $targetGraphics = [System.Drawing.Graphics]::FromImage($target)
  $targetGraphics.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
  $targetGraphics.DrawImage($bitmap, 0, 0, $size, $size)
  $target.Save($outputPath, [System.Drawing.Imaging.ImageFormat]::Png)
  $targetGraphics.Dispose(); $target.Dispose(); $format.Dispose(); $font.Dispose(); $gold.Dispose(); $burgundy.Dispose(); $graphics.Dispose(); $bitmap.Dispose()
}

New-SquareIcon 16 (Join-Path $publicDir 'favicon-16x16.png')
New-SquareIcon 32 (Join-Path $publicDir 'favicon-32x32.png')
New-SquareIcon 180 (Join-Path $publicDir 'apple-touch-icon.png')
New-SquareIcon 192 (Join-Path $publicDir 'icon-192.png')
New-SquareIcon 512 (Join-Path $publicDir 'icon-512.png')

$pngPaths = @((Join-Path $publicDir 'favicon-16x16.png'), (Join-Path $publicDir 'favicon-32x32.png'))
$pngData = @($pngPaths | ForEach-Object { [System.IO.File]::ReadAllBytes($_) })
$icoPath = Join-Path $publicDir 'favicon.ico'
$stream = [System.IO.File]::Create($icoPath)
$writer = New-Object System.IO.BinaryWriter($stream)
$writer.Write([UInt16]0); $writer.Write([UInt16]1); $writer.Write([UInt16]$pngData.Count)
$offset = 6 + (16 * $pngData.Count)
for ($i = 0; $i -lt $pngData.Count; $i++) {
  $dimension = if ($i -eq 0) { 16 } else { 32 }
  $writer.Write([byte]$dimension); $writer.Write([byte]$dimension); $writer.Write([byte]0); $writer.Write([byte]0)
  $writer.Write([UInt16]1); $writer.Write([UInt16]32); $writer.Write([UInt32]$pngData[$i].Length); $writer.Write([UInt32]$offset)
  $offset += $pngData[$i].Length
}
foreach ($bytes in $pngData) { $writer.Write($bytes) }
$writer.Dispose(); $stream.Dispose()

$width = 1200; $height = 630
$og = New-Object System.Drawing.Bitmap($width, $height)
$g = [System.Drawing.Graphics]::FromImage($og)
$g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
$g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
$g.TextRenderingHint = [System.Drawing.Text.TextRenderingHint]::AntiAliasGridFit
$g.Clear([System.Drawing.ColorTranslator]::FromHtml('#641e2f'))

$portrait = [System.Drawing.Image]::FromFile($portraitPath)
$photoX = 700; $photoWidth = $width - $photoX
$sourceWidth = [int]($portrait.Height * ($photoWidth / $height))
$sourceX = [int](($portrait.Width - $sourceWidth) / 2)
$g.DrawImage($portrait, (New-Object System.Drawing.Rectangle($photoX, 0, $photoWidth, $height)), $sourceX, 0, $sourceWidth, $portrait.Height, [System.Drawing.GraphicsUnit]::Pixel)

$ink = New-Object System.Drawing.SolidBrush([System.Drawing.ColorTranslator]::FromHtml('#211a18'))
$gold = New-Object System.Drawing.SolidBrush([System.Drawing.ColorTranslator]::FromHtml('#d6a632'))
$cream = New-Object System.Drawing.SolidBrush([System.Drawing.ColorTranslator]::FromHtml('#f6efe4'))
$g.FillRectangle($ink, 670, 0, 34, $height)

if (Test-Path -LiteralPath $SocialSource) {
  $generated = [System.Drawing.Image]::FromFile($SocialSource)
  $stripX = [int]($generated.Width * 0.53)
  $stripWidth = [int]($generated.Width * 0.08)
  $g.DrawImage($generated, (New-Object System.Drawing.Rectangle(630, 0, 74, $height)), $stripX, 0, $stripWidth, $generated.Height, [System.Drawing.GraphicsUnit]::Pixel)
  $generated.Dispose()
}

$titleFont = New-Object System.Drawing.Font('Georgia', 84, [System.Drawing.FontStyle]::Bold, [System.Drawing.GraphicsUnit]::Pixel)
$labelFont = New-Object System.Drawing.Font('Arial', 31, [System.Drawing.FontStyle]::Bold, [System.Drawing.GraphicsUnit]::Pixel)
$subFont = New-Object System.Drawing.Font('Georgia', 27, [System.Drawing.FontStyle]::Italic, [System.Drawing.GraphicsUnit]::Pixel)
$g.DrawString('Aisha Onola', $titleFont, $cream, 70, 130)
$g.DrawString('Writer in Lagos', $labelFont, $gold, 75, 270)
$g.DrawString('Personal essays and The OffScript', $subFont, $cream, 75, 340)
$g.FillRectangle($gold, 75, 410, 190, 7)

$jpegCodec = [System.Drawing.Imaging.ImageCodecInfo]::GetImageEncoders() | Where-Object { $_.MimeType -eq 'image/jpeg' }
$encoder = [System.Drawing.Imaging.Encoder]::Quality
$parameters = New-Object System.Drawing.Imaging.EncoderParameters(1)
$parameters.Param[0] = New-Object System.Drawing.Imaging.EncoderParameter($encoder, [long]88)
$og.Save((Join-Path $publicDir 'og-image.jpg'), $jpegCodec, $parameters)

$parameters.Dispose(); $subFont.Dispose(); $labelFont.Dispose(); $titleFont.Dispose(); $cream.Dispose(); $gold.Dispose(); $ink.Dispose(); $portrait.Dispose(); $g.Dispose(); $og.Dispose()
