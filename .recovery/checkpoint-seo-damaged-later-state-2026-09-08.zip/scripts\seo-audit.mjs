import fs from 'node:fs';
import path from 'node:path';
import { ROOT, SITE_URL, loadAllWriting, validateWriting } from './content.mjs';

const dist = path.join(ROOT, 'dist');
const writing = validateWriting(loadAllWriting());
const routes = [
  { pathname: '/', file: 'index.html', kind: 'home' },
  { pathname: '/personal/', file: 'personal/index.html', kind: 'collection' },
  { pathname: '/offscript/', file: 'offscript/index.html', kind: 'collection' },
  { pathname: '/explore/', file: 'explore/index.html', kind: 'collection' },
  ...writing.map((item) => ({ pathname: `/writing/${item.slug}/`, file: `writing/${item.slug}/index.html`, kind: 'article', item }))
];
const errors = [];
const titles = new Map();
const descriptions = new Map();
const canonicals = new Set();

const decodeHtml = (value = '') => value
  .replace(/&#(\d+);/g, (_, code) => String.fromCodePoint(Number(code)))
  .replace(/&#x([0-9a-f]+);/gi, (_, code) => String.fromCodePoint(Number.parseInt(code, 16)))
  .replaceAll('&amp;', '&')
  .replaceAll('&quot;', '"')
  .replaceAll('&lt;', '<')
  .replaceAll('&gt;', '>');
const attribute = (html, tagPattern, name) => html.match(new RegExp(`<${tagPattern}[^>]*\\b${name}="([^"]*)"[^>]*>`, 'i'))?.[1];
const meta = (html, key, value) => html.match(new RegExp(`<meta[^>]*\\b${key}="${value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}"[^>]*\\bcontent="([^"]*)"[^>]*>`, 'i'))?.[1]
  || html.match(new RegExp(`<meta[^>]*\\bcontent="([^"]*)"[^>]*\\b${key}="${value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}"[^>]*>`, 'i'))?.[1];
const localPath = (urlPath) => {
  const clean = urlPath.split(/[?#]/)[0];
  if (clean === '/') return path.join(dist, 'index.html');
  if (clean.endsWith('/')) return path.join(dist, clean.slice(1), 'index.html');
  return path.join(dist, clean.slice(1));
};
const addUnique = (map, value, label, route) => {
  if (!value) return errors.push(`${route}: missing ${label}`);
  if (map.has(value)) errors.push(`${route}: duplicate ${label} also used by ${map.get(value)}`);
  map.set(value, route);
};
const pngSize = (file) => {
  const bytes = fs.readFileSync(file);
  if (bytes.toString('ascii', 1, 4) !== 'PNG') return [];
  return [bytes.readUInt32BE(16), bytes.readUInt32BE(20)];
};
const jpegSize = (file) => {
  const bytes = fs.readFileSync(file);
  let offset = 2;
  while (offset < bytes.length) {
    if (bytes[offset] !== 0xff) { offset++; continue; }
    const marker = bytes[offset + 1];
    const length = bytes.readUInt16BE(offset + 2);
    if ([0xc0, 0xc1, 0xc2, 0xc3, 0xc5, 0xc6, 0xc7, 0xc9, 0xca, 0xcb, 0xcd, 0xce, 0xcf].includes(marker)) return [bytes.readUInt16BE(offset + 7), bytes.readUInt16BE(offset + 5)];
    offset += 2 + length;
  }
  return [];
};

const coreExpected = {
  '/': ['Aisha Onola | Writer and Creator of The OffScript', 'Aisha Onola is a Nigerian writer in Lagos and the creator of The OffScript. Read her personal essays and reported stories about life in Nigeria.'],
  '/personal/': ['Personal Writing | Aisha Onola', 'Personal essays by Aisha Onola about identity, relationships, culture, work and figuring things out in public.'],
  '/offscript/': ['The OffScript | Aisha Onola', 'The OffScript is Aisha Onola’s collection of reported stories explaining the politics, money, technology and systems shaping everyday life in Nigeria.'],
  '/explore/': ['Explore the Writing | Aisha Onola', 'Follow the connections between Aisha Onola’s personal observations and reported stories about everyday life in Nigeria.']
};

for (const route of routes) {
  const file = path.join(dist, route.file);
  if (!fs.existsSync(file)) { errors.push(`${route.pathname}: route file is missing`); continue; }
  const html = fs.readFileSync(file, 'utf8');
  const title = decodeHtml(html.match(/<title>([^<]+)<\/title>/i)?.[1]);
  const description = decodeHtml(meta(html, 'name', 'description'));
  const canonical = html.match(/<link[^>]*rel="canonical"[^>]*href="([^"]+)"[^>]*>/i)?.[1];
  const expectedCanonical = `${SITE_URL}${route.pathname}`;
  addUnique(titles, title, 'title', route.pathname);
  addUnique(descriptions, description, 'description', route.pathname);
  if (canonical !== expectedCanonical) errors.push(`${route.pathname}: canonical is ${canonical || 'missing'}, expected ${expectedCanonical}`);
  if (canonicals.has(canonical)) errors.push(`${route.pathname}: canonical is duplicated`);
  canonicals.add(canonical);
  if ((html.match(/<link[^>]*rel="canonical"/gi) || []).length !== 1) errors.push(`${route.pathname}: must have exactly one canonical`);
  if ((html.match(/<h1\b/gi) || []).length !== 1) errors.push(`${route.pathname}: must have exactly one H1`);
  if (/\b(?:noindex|nofollow)\b/i.test(html)) errors.push(`${route.pathname}: contains noindex or nofollow`);
  if (/writing\.aishaonola\.me|localhost|127\.0\.0\.1|pages\.dev|workers\.dev|trycloudflare|ngrok/i.test(html)) errors.push(`${route.pathname}: contains an old, preview, or development URL`);
  if (/issue(?:s)?[\s/_-]*00[67]/i.test(html)) errors.push(`${route.pathname}: contains excluded Issue 006 or 007`);

  for (const [key, value] of [['property', 'og:type'], ['property', 'og:site_name'], ['property', 'og:title'], ['property', 'og:description'], ['property', 'og:url'], ['property', 'og:image'], ['property', 'og:image:secure_url'], ['property', 'og:image:width'], ['property', 'og:image:height'], ['property', 'og:image:alt'], ['name', 'twitter:card'], ['name', 'twitter:title'], ['name', 'twitter:description'], ['name', 'twitter:image'], ['name', 'twitter:image:alt']]) {
    if (!meta(html, key, value)) errors.push(`${route.pathname}: missing ${value}`);
  }
  if (meta(html, 'property', 'og:url') !== expectedCanonical) errors.push(`${route.pathname}: og:url is not canonical`);
  if (meta(html, 'name', 'twitter:card') !== 'summary_large_image') errors.push(`${route.pathname}: X card is not summary_large_image`);
  for (const required of ['/favicon.ico', '/favicon.svg', '/favicon-32x32.png', '/favicon-16x16.png', '/apple-touch-icon.png', '/site.webmanifest']) if (!html.includes(`href="${required}"`)) errors.push(`${route.pathname}: missing head reference ${required}`);

  const jsonScripts = [...html.matchAll(/<script type="application\/ld\+json">([\s\S]*?)<\/script>/gi)];
  if (jsonScripts.length !== 1) errors.push(`${route.pathname}: expected one JSON-LD graph, found ${jsonScripts.length}`);
  let graph = [];
  try { graph = JSON.parse(jsonScripts[0]?.[1] || '{}')['@graph'] || []; } catch { errors.push(`${route.pathname}: JSON-LD is invalid JSON`); }
  const person = graph.find((entry) => entry['@type'] === 'Person');
  const website = graph.find((entry) => entry['@type'] === 'WebSite');
  if (person?.name !== 'Aisha Onola' || person?.jobTitle !== 'Writer' || person?.url !== `${SITE_URL}/`) errors.push(`${route.pathname}: Person identity is incomplete`);
  if (website?.url !== `${SITE_URL}/` || website?.creator?.['@id'] !== `${SITE_URL}/#aisha-onola`) errors.push(`${route.pathname}: WebSite identity is incomplete`);
  if (route.kind === 'collection' && !graph.some((entry) => entry['@type'] === 'CollectionPage' && entry.url === expectedCanonical)) errors.push(`${route.pathname}: CollectionPage schema is missing`);
  if (route.kind === 'article') {
    const article = graph.find((entry) => ['Article', 'NewsArticle', 'BlogPosting'].includes(entry['@type']));
    if (!article) errors.push(`${route.pathname}: Article schema is missing`);
    if (article?.author?.['@id'] !== `${SITE_URL}/#aisha-onola`) errors.push(`${route.pathname}: article author is not Aisha Onola`);
    if (article?.url !== expectedCanonical || article?.mainEntityOfPage?.['@id'] !== expectedCanonical) errors.push(`${route.pathname}: article structured URL is not canonical`);
    if (title !== `${route.item.title} | Aisha Onola`) errors.push(`${route.pathname}: article title pattern is incorrect`);
    if (description !== route.item.subtitle) errors.push(`${route.pathname}: article description does not match its standfirst`);
    if (meta(html, 'property', 'og:type') !== 'article') errors.push(`${route.pathname}: og:type must be article`);
    if (meta(html, 'property', 'article:author') !== 'Aisha Onola') errors.push(`${route.pathname}: article author meta is missing`);
    if (!html.includes('By Aisha Onola')) errors.push(`${route.pathname}: visible author byline is missing`);
  } else if (coreExpected[route.pathname]) {
    const [expectedTitle, expectedDescription] = coreExpected[route.pathname];
    if (title !== expectedTitle) errors.push(`${route.pathname}: core title is incorrect`);
    if (description !== expectedDescription) errors.push(`${route.pathname}: core description is incorrect`);
    if (meta(html, 'property', 'og:image') !== `${SITE_URL}/og-image.jpg`) errors.push(`${route.pathname}: site-wide OG image is not configured`);
  }

  for (const match of html.matchAll(/<(?:a|link|script|img)\b[^>]*(?:href|src)="(\/[^"]*)"[^>]*>/gi)) {
    const target = match[1];
    if (target.startsWith('//')) continue;
    if (!fs.existsSync(localPath(target))) errors.push(`${route.pathname}: missing internal target ${target}`);
  }
  for (const image of html.matchAll(/<img\b([^>]*)>/gi)) {
    if (!/\balt="[^"]*"/.test(image[1])) errors.push(`${route.pathname}: image is missing alt text`);
    if (!/\bwidth="\d+"/.test(image[1]) || !/\bheight="\d+"/.test(image[1])) errors.push(`${route.pathname}: image is missing intrinsic dimensions`);
    if (!/\bdecoding="async"/.test(image[1])) errors.push(`${route.pathname}: image decoding is not asynchronous`);
  }
}

const requiredAssets = {
  'favicon-16x16.png': [16, 16],
  'favicon-32x32.png': [32, 32],
  'apple-touch-icon.png': [180, 180],
  'icon-192.png': [192, 192],
  'icon-512.png': [512, 512]
};
for (const [name, expected] of Object.entries(requiredAssets)) {
  const file = path.join(dist, name);
  if (!fs.existsSync(file)) errors.push(`Missing favicon asset: ${name}`);
  else if (pngSize(file).join('x') !== expected.join('x')) errors.push(`${name}: incorrect dimensions`);
}
for (const name of ['favicon.ico', 'favicon.svg']) if (!fs.existsSync(path.join(dist, name))) errors.push(`Missing favicon asset: ${name}`);
if (fs.existsSync(path.join(dist, 'favicon.ico'))) {
  const ico = fs.readFileSync(path.join(dist, 'favicon.ico'));
  if (ico.readUInt16LE(0) !== 0 || ico.readUInt16LE(2) !== 1 || ico.readUInt16LE(4) < 2) errors.push('favicon.ico is not a valid multi-image icon');
}
const ogFile = path.join(dist, 'og-image.jpg');
if (!fs.existsSync(ogFile) || jpegSize(ogFile).join('x') !== '1200x630') errors.push('og-image.jpg must be a valid 1200x630 JPEG');

const manifestPath = path.join(dist, 'site.webmanifest');
try {
  const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
  if (!manifest.icons?.some((icon) => icon.src === '/icon-192.png' && icon.sizes === '192x192')) errors.push('Manifest is missing the 192x192 icon');
  if (!manifest.icons?.some((icon) => icon.src === '/icon-512.png' && icon.sizes === '512x512')) errors.push('Manifest is missing the 512x512 icon');
} catch { errors.push('site.webmanifest is missing or invalid JSON'); }

const sitemap = fs.readFileSync(path.join(dist, 'sitemap.xml'), 'utf8');
const sitemapUrls = [...sitemap.matchAll(/<loc>([^<]+)<\/loc>/g)].map((match) => match[1]);
const expectedUrls = routes.map((route) => `${SITE_URL}${route.pathname}`);
if (new Set(sitemapUrls).size !== sitemapUrls.length) errors.push('Sitemap contains duplicate URLs');
if (sitemapUrls.length !== expectedUrls.length || expectedUrls.some((url) => !sitemapUrls.includes(url))) errors.push('Sitemap route set does not match the 13 canonical routes');
if (/006|007|pages\.dev|workers\.dev|writing\.aishaonola\.me/i.test(sitemap)) errors.push('Sitemap contains an excluded issue or nonproduction URL');
const robots = fs.readFileSync(path.join(dist, 'robots.txt'), 'utf8');
if (!robots.includes('User-agent: *\nAllow: /') || !robots.includes(`Sitemap: ${SITE_URL}/sitemap.xml`) || /Disallow:\s*\//i.test(robots)) errors.push('robots.txt is not production-ready');

if (errors.length) {
  console.error(`SEO audit failed (${errors.length}):\n${errors.map((error) => `- ${error}`).join('\n')}`);
  process.exit(1);
}

console.log(`SEO audit passed: ${routes.length} canonical routes, ${writing.length} authored stories, complete social metadata, valid JSON-LD, favicon system, manifest, sitemap, robots, internal links, and assets.`);
