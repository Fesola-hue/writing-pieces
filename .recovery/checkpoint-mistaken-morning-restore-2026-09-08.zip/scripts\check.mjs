import fs from 'node:fs';
import path from 'node:path';
import { ROOT, CURATED_OFFSCRIPT_SLUGS, loadAllWriting, validateWriting } from './content.mjs';

const writing = validateWriting(loadAllWriting());
const personal = writing.filter((item) => item.kind === 'personal');
const offscript = writing.filter((item) => item.kind === 'offscript');
const errors = [];
const RETIRED_SLUGS = ['offscript-006', 'offscript-007'];

const normalizeQuotes = (text) => text.replace(/[\u2018\u2019]/g, "'").replace(/[\u201c\u201d]/g, '"');
const htmlToText = (html) => normalizeQuotes(html.replace(/<script[\s\S]*?<\/script>/gi, '').replace(/<style[\s\S]*?<\/style>/gi, '').replace(/<[^>]+>/g, ' ').replaceAll('&amp;', '&').replaceAll('&#39;', "'").replaceAll('&#8217;', "'").replaceAll('&quot;', '"').replace(/\s+/g, ' ').trim());
const sourceParagraphs = (body) => body.replaceAll('\r\n', '\n').split(/\n\s*\n/)
  .map((p) => normalizeQuotes(p.replaceAll('\n', ' ').replace(/\*\*|_/g, '').replace(/\s+/g, ' ').trim()))
  .filter(Boolean)
  .filter((p) => !/^\.{2,}$/.test(p));
const readOutput = (relativePath) => {
  const output = path.join(ROOT, 'dist', relativePath);
  if (!fs.existsSync(output)) { errors.push(`Missing generated route: ${relativePath}`); return ''; }
  return fs.readFileSync(output, 'utf8');
};

// ---- curated collection shape --------------------------------------------
if (personal.length !== 4) errors.push(`Expected 4 personal pieces, found ${personal.length}`);
if (offscript.length !== 5) errors.push(`Expected 5 curated OffScript issues, found ${offscript.length}`);
if (CURATED_OFFSCRIPT_SLUGS.length !== 5) errors.push('CURATED_OFFSCRIPT_SLUGS should list exactly 5 issues');
for (const item of writing) {
  for (const retired of RETIRED_SLUGS) {
    if (item.slug.startsWith(retired)) errors.push(`${item.slug}: retired issue must not appear in the build`);
  }
}
if (!fs.existsSync(path.join(ROOT, 'content', 'personal-originals'))) errors.push('Original essay text was not preserved before editing');

// ---- routes exist ----------------------------------------------------------
const homepage = readOutput('index.html');
const personalPage = readOutput(path.join('personal', 'index.html'));
const offscriptPage = readOutput(path.join('offscript', 'index.html'));
const explorePage = readOutput(path.join('explore', 'index.html'));
for (const retired of RETIRED_SLUGS) {
  if (fs.existsSync(path.join(ROOT, 'dist', 'writing')) && fs.readdirSync(path.join(ROOT, 'dist', 'writing')).some((entry) => entry.startsWith(retired))) {
    errors.push(`A retired issue route (${retired}) was built and must be removed`);
  }
}

// ---- homepage: human entrance + real writing early + curated, not complete
if (!homepage.includes('/images/aisha-onola.jpg')) errors.push('Homepage is missing the portrait');
if (homepage.includes('generic team-profile') || homepage.match(/class="[^"]*avatar[^"]*"/)) errors.push('Homepage portrait looks like a generic avatar treatment');
if (!homepage.includes('class="opening-excerpt"')) errors.push('Homepage is missing an early real-writing excerpt beneath the introduction');
const homepageArticleLinks = new Set([...homepage.matchAll(/href="(\/writing\/[^"]+)"/g)].map((m) => m[1]));
if (homepageArticleLinks.size >= writing.length) errors.push('Homepage should curate a selection, not link every piece in the collection');
if (homepageArticleLinks.size < 4) errors.push('Homepage curated selection looks too thin');
if (!homepage.includes('is-personal') || !homepage.includes('is-offscript')) errors.push('Homepage curated selection should mix Personal and OffScript pieces');
if (!homepage.includes('Get in touch')) errors.push('Homepage is missing the quiet contact line');
const bannedHomeCopy = ['Welcome to my world', 'small library of things', 'Words that outlive Fridays', 'intersection of', 'stories that shape us', 'thought leader', 'Why work with me', 'services', 'résumé'];
for (const phrase of bannedHomeCopy) if (homepage.toLowerCase().includes(phrase.toLowerCase())) errors.push(`Homepage contains banned copy pattern: "${phrase}"`);

// ---- no hamburger-only nav; bottom tab bar + desktop header present -------
for (const html of [homepage, personalPage, offscriptPage, explorePage]) {
  if (!html.includes('class="tab-bar"')) errors.push('A primary route is missing the persistent mobile tab bar');
  if (!html.includes('class="top-nav"')) errors.push('A primary route is missing the desktop header nav');
  if (html.includes('hamburger') || html.includes('menu-toggle')) errors.push('Primary navigation should not be hidden behind a hamburger menu');
}

// ---- Personal / OffScript collections: not a paged swipe-only deck --------
if ((personalPage.match(/class="essay-block/g) || []).length !== personal.length) errors.push('Personal collection page does not render every personal piece');
if (personalPage.includes('data-slide') || personalPage.includes('deck-controller')) errors.push('Personal collection should not be a swipe-only single-item deck');
if ((offscriptPage.match(/class="issue-block/g) || []).length !== offscript.length) errors.push('OffScript collection page does not render every curated issue');
if (!offscriptPage.includes('theoffscript.page')) errors.push('OffScript collection is missing the unobtrusive link to the full external archive');
if (offscriptPage.includes('class="spine"')) errors.push('OffScript collection should not reuse the retired book-spine interface');

// ---- Explore: trail, not a hover/SVG-dependent network diagram -----------
if (!explorePage.includes('data-trail') || !explorePage.includes('data-trail-item')) errors.push('Explore route is not built around the trail interaction');
if ((explorePage.match(/data-trail-item/g) || []).length !== writing.length) errors.push('Explore trail does not contain every piece');
if (explorePage.includes('<svg') && explorePage.match(/<svg[^>]*id="lines"/)) errors.push('Explore should not depend on desktop SVG connector lines');
for (const retired of RETIRED_SLUGS) if (explorePage.includes(retired)) errors.push(`Explore route references retired issue ${retired}`);

// ---- article pages: full body, one real connection, structured data ------
for (const item of writing) {
  const html = readOutput(path.join('writing', item.slug, 'index.html'));
  if (!html) continue;
  const pageText = htmlToText(html);
  const missingParagraphs = sourceParagraphs(item.body).filter((para) => !pageText.includes(para));
  if (missingParagraphs.length) errors.push(`${item.slug}: ${missingParagraphs.length} paragraph(s) from the source body are missing from the rendered article`);
  if (item.originalUrl && !html.includes(`href="${item.originalUrl.replaceAll('&', '&amp;')}"`)) errors.push(`${item.slug}: original publication link is absent`);
  if (!html.includes('class="connection ')) errors.push(`${item.slug}: is missing its one real "keep reading" connection`);
  if ((html.match(/class="connection-card"/g) || []).length > 1) errors.push(`${item.slug}: should offer one meaningful connection, not a related-posts grid`);
  if (!html.includes('application/ld+json')) errors.push(`${item.slug}: structured article data is absent`);
  if (!html.includes('class="tab-bar"')) errors.push(`${item.slug}: is missing the persistent mobile tab bar`);
  for (const retired of RETIRED_SLUGS) if (html.includes(`/writing/${retired}`)) errors.push(`${item.slug}: links to a retired issue`);
}

// ---- no navigation-delaying decorative transition JS ----------------------
const clientScript = fs.readFileSync(path.join(ROOT, 'public', 'site.js'), 'utf8');
if (clientScript.includes('setTimeout') && clientScript.includes('location.href')) errors.push('site.js appears to delay navigation for a decorative transition');
if (clientScript.includes('route-leaving')) errors.push('Retired route-wipe transition hack is still present');

// ---- accessibility / performance basics ------------------------------------
const styles = fs.readFileSync(path.join(ROOT, 'public', 'styles.css'), 'utf8');
if (!styles.includes('prefers-reduced-motion')) errors.push('Reduced-motion support is absent from styles.css');
if (!styles.includes(':focus-visible')) errors.push('Visible focus states are absent from styles.css');
if (!homepage.includes('skip-link')) errors.push('Skip-to-content link is absent');
if (!fs.existsSync(path.join(ROOT, 'dist', 'sitemap.xml'))) errors.push('Sitemap was not built');
if (!fs.existsSync(path.join(ROOT, 'dist', 'robots.txt'))) errors.push('robots.txt was not built');
const sitemap = fs.readFileSync(path.join(ROOT, 'dist', 'sitemap.xml'), 'utf8');
const sitemapUrlCount = (sitemap.match(/<loc>/g) || []).length;
if (sitemapUrlCount !== 4 + writing.length) errors.push(`Sitemap should contain ${4 + writing.length} URLs, found ${sitemapUrlCount}`);
for (const retired of RETIRED_SLUGS) if (sitemap.includes(retired)) errors.push(`Sitemap references retired issue ${retired}`);

if (errors.length) {
  console.error(`Checks failed (${errors.length}):\n${errors.map((error) => `- ${error}`).join('\n')}`);
  process.exit(1);
}
console.log(`Checks passed: ${personal.length} personal + ${offscript.length} curated OffScript = ${writing.length} pieces; 4 collection routes; ${writing.length} article routes; retired issues absent; mobile tab bar + desktop nav; single real connection per piece; schema; sitemap; a11y hooks.`);
