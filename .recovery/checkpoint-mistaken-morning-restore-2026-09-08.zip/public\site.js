(() => {
  'use strict';

  // ---- reading progress ---------------------------------------------------
  const progress = document.querySelector('.reading-progress i');
  if (progress) {
    const article = document.querySelector('.article-body');
    const setProgress = () => {
      if (!article) return;
      const rect = article.getBoundingClientRect();
      const total = rect.height - window.innerHeight;
      const scrolled = Math.min(Math.max(-rect.top, 0), Math.max(total, 1));
      progress.style.transform = `scaleX(${total > 0 ? scrolled / total : 0})`;
    };
    setProgress();
    window.addEventListener('scroll', setProgress, { passive: true });
    window.addEventListener('resize', setProgress);
  }

  // ---- notes on this piece (disclosure) ------------------------------------
  document.querySelectorAll('[data-behind]').forEach((section) => {
    const toggle = section.querySelector('.behind-toggle');
    const drawer = section.querySelector('.behind-drawer');
    if (!toggle || !drawer) return;
    toggle.addEventListener('click', () => {
      const open = toggle.getAttribute('aria-expanded') === 'true';
      toggle.setAttribute('aria-expanded', String(!open));
      drawer.hidden = open;
    });
  });

  // ---- Explore: follow a thought ------------------------------------------
  const trailWrap = document.querySelector('[data-trail]');
  if (trailWrap) {
    const buttons = Array.from(document.querySelectorAll('.theme-picker button'));
    const items = Array.from(trailWrap.querySelectorAll('[data-trail-item]'));
    const countEl = trailWrap.querySelector('[data-map-count]');
    const labelEl = trailWrap.querySelector('[data-theme-label]');
    const descEls = Array.from(trailWrap.querySelectorAll('[data-theme-desc]'));

    const applyTheme = (theme) => {
      let visible = 0;
      items.forEach((item) => {
        const topics = (item.dataset.topics || '').split('|');
        const matches = topics.includes(theme);
        item.hidden = !matches;
        if (matches) {
          visible += 1;
          item.querySelectorAll('.trail-topics em').forEach((em) => {
            em.classList.toggle('is-match', em.dataset.topic === theme);
          });
        }
      });
      buttons.forEach((btn) => btn.setAttribute('aria-pressed', String(btn.dataset.theme === theme)));
      descEls.forEach((el) => { el.hidden = el.dataset.themeDesc !== theme; });
      if (labelEl) {
        const active = buttons.find((btn) => btn.dataset.theme === theme);
        labelEl.textContent = active ? active.textContent.replace(/\d+$/, '').trim() : theme;
      }
      if (countEl) countEl.textContent = String(visible);
    };

    buttons.forEach((btn) => btn.addEventListener('click', () => applyTheme(btn.dataset.theme)));
    applyTheme(trailWrap.dataset.initialTheme);
  }
})();
