import fs from 'node:fs';
import path from 'node:path';
import { ROOT, SITE_URL, escapeHtml, formatDate, loadAllWriting, validateWriting } from './content.mjs';

const dist = path.join(ROOT, 'dist');
const writing = validateWriting(loadAllWriting());
const personal = writing.filter((item) => item.kind === 'personal');
const offscript = writing.filter((item) => item.kind === 'offscript').sort((a, b) => a.issueNumber.localeCompare(b.issueNumber));
const bySlug = Object.fromEntries(writing.map((item) => [item.slug, item]));

const PERSON_ID = `${SITE_URL}/#aisha-onola`;
const WEBSITE_ID = `${SITE_URL}/#website`;
const DEFAULT_OG_IMAGE = '/og-image.jpg';
const DEFAULT_OG_ALT = 'Aisha Onola, writer in Lagos, with the words Personal essays and The OffScript';

const personEntity = {
  '@type': 'Person',
  '@id': PERSON_ID,
  name: 'Aisha Onola',
  url: `${SITE_URL}/`,
  image: `${SITE_URL}/images/aisha-onola.jpg`,
  jobTitle: 'Writer',
  description: 'Aisha Onola is a Nigerian writer based in Lagos and the creator and writer of The OffScript.',
  knowsAbout: ['Personal essays', 'Nigerian culture', 'Technology', 'Money', 'Politics', 'Everyday life in Nigeria'],
  sameAs: ['https://aishaonola.me', 'https://aishaonola.medium.com/', 'https://aishaonola.substack.com/']
};

const websiteEntity = {
  '@type': 'WebSite',
  '@id': WEBSITE_ID,
  name: 'Aisha Onola | Writing',
  url: `${SITE_URL}/`,
  description: 'Personal essays and reported stories by Aisha Onola, a Nigerian writer in Lagos and creator of The OffScript.',
  creator: { '@id': PERSON_ID },
  publisher: { '@id': PERSON_ID }
};

const pad = (number, length = 3) => String(number).padStart(length, '0');
const internal = (item) => `/writing/${item.slug}/`;
const absolute = (pathname) => `${SITE_URL}${pathname}`;
const categoryClass = (item) => (item.kind === 'offscript' ? 'is-offscript' : 'is-personal');
const kindLabel = (item) => (item.kind === 'offscript' ? `The OffScript · Issue ${item.issueNumber}` : 'Personal writing');

// ---------------------------------------------------------------------------
// Editorial data. Hand-picked, not auto-generated: real excerpts, real reasons
// two pieces belong next to each other, real structural cues for each article
// family. Paragraph indices below refer to the blank-line-separated paragraphs
// of each piece's own body text (0-indexed) and were counted directly against
// the source so insertions land on exact sentences, never guessed.
// ---------------------------------------------------------------------------

const EXCERPTS = {
  'people-who-made-my-world': 'Maybe where you live isn’t the only environment that raises you.',
  'so-i-started-dating-myself': 'I spent my teenage years trying to love myself, and every time I thought I had, it fell apart.',
  'it-kinda-chic-to-stay': 'How are we this online and still missing things?',
  'that-not-what-decentering-men': 'I’d say we should decenter everyone. Have an identity outside your relationships.',
  'offscript-005-we-make-enough-cement-to-export-it-so-why-is-a-bag-still-13-000': '₦13,000–15,000 a bag here in July 2026. ₦9,300 in January. Kenya, which imports its cement, paid about ₦7,344.',
  'offscript-003-nigeria-is-quietly-having-one-of-its-best-years-internationally-here-s-why-you-still-don-t-feel-it': 'Go to any market in Lagos and ask how people are feeling. The answer won’t match those headlines.',
  'offscript-004-nigeria-doesn-t-have-an-ai-problem-it-has-an-ownership-problem': 'Nine in ten Nigerian adults have used an AI chatbot. None of it runs on a server Nigeria owns.',
  'offscript-002-the-us-is-quietly-locking-nigerians-out': 'No big announcement. No single ban. Just three separate policy updates, easy to miss on their own.',
  'offscript-001-everyone-argued-about-a-uniform-they-missed-the-real-reform': 'The uniform was never really the story. It’s one small piece of the biggest NYSC shake-up in 53 years.'
};

const TOPIC_DESC = {
  'nigeria': 'Stories rooted in what’s actually happening on the ground.',
  'systems': 'The structures behind a headline — policy, institutions, money flows.',
  'identity': 'Who you are, underneath the roles other people hand you.',
  'money': 'What things cost, and what that cost actually means day to day.',
  'technology': 'Tools everyone’s using, and the question of who owns them.',
  'work': 'Jobs, ambition, and the version of a career nobody quite warns you about.',
  'culture': 'The discourse, and the reform that’s sometimes hiding behind it.',
  'belonging': 'Where you’re from, and who else quietly shaped you.',
  'people': 'The individuals who change what feels possible for someone else.',
  'everyday life': 'How a big number actually lands on an ordinary week.',
  'internet feminism': 'Online talking points, and what they actually mean up close.',
  'internet culture': 'Being online, and mistaking it for being informed.',
  'information': 'What’s easy to find, and what’s easy to miss completely.',
  'self-knowledge': 'Learning who you are without leaning on anyone else’s script.',
  'housing': 'Owning or renting a roof, and why it’s harder than it should be.',
  'ownership': 'Using a thing versus actually controlling it.',
  'mobility': 'Getting in, getting out, getting through the door at all.',
  'education': 'School, training, and who actually gets to finish it.'
};

// One outbound "keep reading" connection per piece, chosen for a real, stated
// reason (not topic-matching alone). Together they form a path through all
// nine pieces rather than a generic related-posts grid.
const CONNECTIONS = {
  'people-who-made-my-world': {
    to: 'it-kinda-chic-to-stay',
    kicker: 'Keep reading',
    note: 'The people who quietly expanded my world are a big part of why I started noticing what I was missing, too.'
  },
  'so-i-started-dating-myself': {
    to: 'that-not-what-decentering-men',
    kicker: 'Keep reading',
    note: 'Knowing yourself outside anyone else’s version of you doesn’t stop at self-love. It shows up in how you hold every relationship after.'
  },
  'it-kinda-chic-to-stay': {
    to: 'offscript-001-everyone-argued-about-a-uniform-they-missed-the-real-reform',
    kicker: 'Where it started',
    note: 'This essay is basically the origin story. Issue 001 is the first thing I actually shipped once I stopped just talking about the problem.'
  },
  'that-not-what-decentering-men': {
    to: 'so-i-started-dating-myself',
    kicker: 'Keep reading',
    note: 'Having an identity outside your relationships starts with actually knowing who you are. This is the longer version of how I got there.'
  },
  'offscript-001-everyone-argued-about-a-uniform-they-missed-the-real-reform': {
    to: 'offscript-002-the-us-is-quietly-locking-nigerians-out',
    kicker: 'Same pattern',
    note: 'Same shape, different system: the loud part gets the debate, the quiet part is where the real change happens. Three overlooked visa changes play out the same way.'
  },
  'offscript-002-the-us-is-quietly-locking-nigerians-out': {
    to: 'offscript-004-nigeria-doesn-t-have-an-ai-problem-it-has-an-ownership-problem',
    kicker: 'Keep reading',
    note: 'Fewer doors out, and the people who do get trained at home keep getting pulled away by foreign salaries. Different story, same undertow.'
  },
  'offscript-005-we-make-enough-cement-to-export-it-so-why-is-a-bag-still-13-000': {
    to: 'offscript-003-nigeria-is-quietly-having-one-of-its-best-years-internationally-here-s-why-you-still-don-t-feel-it',
    kicker: 'Keep reading',
    note: 'The gap between a national number and what it actually buys you shows up here too, just with a stock ticker instead of a bag of cement.'
  },
  'offscript-003-nigeria-is-quietly-having-one-of-its-best-years-internationally-here-s-why-you-still-don-t-feel-it': {
    to: 'offscript-004-nigeria-doesn-t-have-an-ai-problem-it-has-an-ownership-problem',
    kicker: 'Keep reading',
    note: 'That rally is being captured by banks and pension funds, not the person checking market prices. The AI story is the same shape: huge usage, almost none of the value coming back to Nigeria.'
  },
  'offscript-004-nigeria-doesn-t-have-an-ai-problem-it-has-an-ownership-problem': {
    to: 'it-kinda-chic-to-stay',
    kicker: 'Keep reading',
    note: 'Wide adoption and zero ownership is its own kind of missing the story. This is the essay about why that gap is so easy to miss in the first place.'
  }
};

const EDITORIAL = {
  'people-who-made-my-world': { family: 'reflective', emphasize: [9, 12] },
  'so-i-started-dating-myself': { family: 'intimate', emphasize: [8, 16], quietTurn: [9] },
  'it-kinda-chic-to-stay': { family: 'bridge', emphasize: [2, 14], bridgeFrom: 10 },
  'that-not-what-decentering-men': { family: 'bridge-compact', emphasize: [5, 7] },
  'offscript-001-everyone-argued-about-a-uniform-they-missed-the-real-reform': {
    family: 'explainer',
    jobTag: 'Culture & policy',
    sectionFlag: { beforeIndex: 3, label: 'The reform buried behind the headline' },
    callout: {
      afterIndex: 3,
      heading: 'What actually changed',
      items: [
        'Camp orientation: three weeks → six weeks',
        'Passing Out Parade becomes a graduation ceremony',
        'Day-to-day leadership moves from military to civilian, security stays military',
        'Proposed: postings finally matched to what corps members studied'
      ]
    }
  },
  'offscript-002-the-us-is-quietly-locking-nigerians-out': {
    family: 'explainer',
    jobTag: 'Practical explainer',
    callout: {
      afterIndex: 0,
      heading: 'Three changes, three weeks apart',
      items: [
        'Abuja’s immigrant-visa office closed. Lagos now handles the whole country.',
        'Student visas capped at four years, with a shorter grace period after graduation.',
        'Most new visas are now single-use: one entry, then you reapply from scratch.'
      ]
    }
  },
  'offscript-005-we-make-enough-cement-to-export-it-so-why-is-a-bag-still-13-000': {
    family: 'analysis',
    jobTag: 'Flagship analysis',
    emphasize: [10],
    statStrip: {
      afterIndex: 2,
      heading: 'Same bag of cement',
      stats: [
        { value: '₦9,300', label: 'January 2026' },
        { value: '₦13–15k', label: 'July 2026, Nigeria' },
        { value: '₦7,344', label: 'Kenya, which imports its cement' }
      ]
    }
  },
  'offscript-003-nigeria-is-quietly-having-one-of-its-best-years-internationally-here-s-why-you-still-don-t-feel-it': {
    family: 'analysis',
    jobTag: 'Economic & political analysis',
    emphasize: [1],
    statStrip: {
      afterIndex: 5,
      heading: 'Two Nigerias, one week',
      stats: [
        { value: '+67–68%', label: 'Lagos stock market since January' },
        { value: '+127%', label: 'Ecobank share price' },
        { value: '35 million', label: 'facing acute hunger this lean season' }
      ]
    }
  },
  'offscript-004-nigeria-doesn-t-have-an-ai-problem-it-has-an-ownership-problem': {
    family: 'analysis',
    jobTag: 'Technology & policy',
    emphasize: [10],
    statStrip: {
      afterIndex: 3,
      heading: 'Wide use, no ownership',
      stats: [
        { value: '9 in 10', label: 'Nigerian adults use an AI chatbot' },
        { value: '$850m', label: 'spent yearly hosting data abroad' },
        { value: '₦17,000', label: 'price gap on the same subscription' }
      ]
    }
  }
};

function rawParagraphs(body) {
  return body.replaceAll('\r\n', '\n').split(/\n\s*\n/)
    .map((p) => p.replaceAll('\n', ' ').trim())
    .filter(Boolean)
    .filter((p) => !/^\.{2,}$/.test(p)); // strip decorative "....." divider left over in source files
}

function smartQuotes(value = '') {
  let text = value;
  text = text.replace(/(^|[\s(])"/g, '$1\u201c');
  text = text.replace(/"/g, '\u201d');
  text = text.replace(/(\w)'(\w)/g, '$1\u2019$2');
  text = text.replace(/'/g, '\u2019');
  return text;
}

function renderInlineLocal(value = '') {
  let text = escapeHtml(smartQuotes(value));
  text = text.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
  return text;
}

function calloutBlock({ heading, items }) {
  return `<aside class="callout"><p class="callout-label">${escapeHtml(heading)}</p><ol class="callout-list">${items.map((entry) => `<li>${renderInlineLocal(entry)}</li>`).join('')}</ol></aside>`;
}

function statStripBlock({ heading, stats }) {
  return `<aside class="stat-strip"><p class="stat-strip-label">${escapeHtml(heading)}</p><div class="stat-strip-row">${stats.map((stat) => `<div class="stat"><strong>${escapeHtml(stat.value)}</strong><span>${escapeHtml(stat.label)}</span></div>`).join('')}</div></aside>`;
}

// Rebuilds an article body paragraph-by-paragraph so structural cues (pull
// lines, a quiet emotional beat, a mid-article callout, a section flag, the
// personal-to-OffScript colour bridge) land on exact, known sentences instead
// of guessing against rendered HTML.
function familyBodyHtml(item) {
  const cfg = EDITORIAL[item.slug] || {};
  const paragraphs = rawParagraphs(item.body);
  const emphasize = new Set(cfg.emphasize || []);
  const quietTurn = new Set(cfg.quietTurn || []);
  let out = '';
  let bridgeOpen = false;
  paragraphs.forEach((para, index) => {
    if (cfg.sectionFlag && cfg.sectionFlag.beforeIndex === index) {
      out += `<p class="section-flag">${escapeHtml(cfg.sectionFlag.label)}</p>`;
    }
    if (cfg.bridgeFrom === index) {
      out += '<div class="bridge-to-offscript">';
      bridgeOpen = true;
    }
    const classes = [];
    if (emphasize.has(index)) classes.push('pull-line');
    if (quietTurn.has(index)) classes.push('quiet-turn');
    const cls = classes.length ? ` class="${classes.join(' ')}"` : '';
    out += `<p${cls}>${renderInlineLocal(para)}</p>`;
    if (cfg.callout && cfg.callout.afterIndex === index) out += calloutBlock(cfg.callout);
    if (cfg.statStrip && cfg.statStrip.afterIndex === index) out += statStripBlock(cfg.statStrip);
  });
  if (bridgeOpen) out += '</div>';
  return out;
}

function copyDir(from, to) {
  fs.mkdirSync(to, { recursive: true });
  for (const entry of fs.readdirSync(from, { withFileTypes: true })) {
    const source = path.join(from, entry.name);
    const target = path.join(to, entry.name);
    entry.isDirectory() ? copyDir(source, target) : fs.copyFileSync(source, target);
  }
}

// ---------------------------------------------------------------------------
// Icons — a small, consistent line-icon set. No doodles, no sparkles.
// ---------------------------------------------------------------------------
const ICONS = {
  home: '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M4 11.5 12 4l8 7.5M6 10v9.5h5V15h2v4.5h5V10" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg>',
  personal: '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M12 12.5a4 4 0 1 0 0-8 4 4 0 0 0 0 8Z" stroke="currentColor" stroke-width="1.7"/><path d="M4.5 20c1.4-3.6 4.2-5.5 7.5-5.5s6.1 1.9 7.5 5.5" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg>',
  offscript: '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M5 4.5h11l3 3V19a.5.5 0 0 1-.5.5H5.5A.5.5 0 0 1 5 19V4.5Z" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"/><path d="M8 10h8M8 13.5h8M8 17h5" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg>',
  explore: '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><circle cx="12" cy="12" r="8" stroke="currentColor" stroke-width="1.7"/><path d="m14.3 9.7-1.4 3.6a1 1 0 0 1-.5.5l-3.6 1.4 1.4-3.6a1 1 0 0 1 .5-.5l3.6-1.4Z" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round"/></svg>',
  mail: '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><rect x="3.5" y="5.5" width="17" height="13" rx="1.4" stroke="currentColor" stroke-width="1.6"/><path d="m4.5 6.5 7.5 6 7.5-6" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>',
  arrow: '<svg class="i-arrow" viewBox="0 0 20 20" fill="none" aria-hidden="true"><path d="M4 10h12M11 5l5 5-5 5" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>',
  external: '<svg class="i-external" viewBox="0 0 20 20" fill="none" aria-hidden="true"><path d="M8.5 5.5H14.5V11.5M14.5 5.5 5.5 14.5" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>'
};

function head({ title, description, pathname = '/', type = 'website', schema }) {
  const pageTitle = title;
  const pageUrl = absolute(pathname);
  const shareImage = absolute(DEFAULT_OG_IMAGE);
  const suppliedSchema = (Array.isArray(schema) ? schema : [schema]).filter(Boolean).map(({ '@context': _context, ...entity }) => entity);
  const structuredData = { '@context': 'https://schema.org', '@graph': [personEntity, websiteEntity, ...suppliedSchema] };
  return `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
  <meta name="theme-color" content="#f7f2e8">
  <link rel="icon" href="/favicon.ico" sizes="any">
  <link rel="icon" href="/favicon.svg" type="image/svg+xml">
  <link rel="icon" href="/favicon-32x32.png" type="image/png" sizes="32x32">
  <link rel="icon" href="/favicon-16x16.png" type="image/png" sizes="16x16">
  <link rel="apple-touch-icon" href="/apple-touch-icon.png" sizes="180x180">
  <link rel="manifest" href="/site.webmanifest">
  <title>${escapeHtml(pageTitle)}</title>
  <meta name="description" content="${escapeHtml(description)}">
  <meta name="author" content="Aisha Onola">
  <link rel="canonical" href="${escapeHtml(pageUrl)}">
  <meta property="og:type" content="${type}">
  <meta property="og:site_name" content="Aisha Onola | Writing">
  <meta property="og:title" content="${escapeHtml(pageTitle)}">
  <meta property="og:description" content="${escapeHtml(description)}">
  <meta property="og:url" content="${escapeHtml(pageUrl)}">
  <meta property="og:image" content="${escapeHtml(shareImage)}">
  <meta property="og:image:secure_url" content="${escapeHtml(shareImage)}">
  <meta property="og:image:width" content="1200">
  <meta property="og:image:height" content="630">
  <meta property="og:image:alt" content="${escapeHtml(DEFAULT_OG_ALT)}">
  <meta name="twitter:card" content="summary_large_image">
  <meta name="twitter:title" content="${escapeHtml(pageTitle)}">
  <meta name="twitter:description" content="${escapeHtml(description)}">
  <meta name="twitter:image" content="${escapeHtml(shareImage)}">
  <meta name="twitter:image:alt" content="${escapeHtml(DEFAULT_OG_ALT)}">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,340;0,9..144,440;0,9..144,560;0,9..144,650;1,9..144,440;1,9..144,560&family=Inter:wght@400;500;600;700&family=IBM+Plex+Mono:wght@500;600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="/styles.css">
  <script src="/site.js" defer></script>
  <script type="application/ld+json">${JSON.stringify(structuredData).replaceAll('<', '\\u003c')}</script>
</head>`;
}

function nav(active) {
  const items = [
    ['home', '/', 'Home', ICONS.home],
    ['personal', '/personal/', 'Personal', ICONS.personal],
    ['offscript', '/offscript/', 'The OffScript', ICONS.offscript],
    ['explore', '/explore/', 'Explore', ICONS.explore]
  ];
  const topLinks = items.map(([key, href, label]) => `<a href="${href}"${active === key ? ' class="active" aria-current="page"' : ''}>${label}</a>`).join('');
  const tabLinks = items.map(([key, href, label, icon]) => `<a href="${href}"${active === key ? ' class="active" aria-current="page"' : ''}>${icon}<span>${label}</span></a>`).join('');
  return `<a class="skip-link" href="#main">Skip to content</a>
<header class="site-header">
  <a class="wordmark" href="https://aishaonola.me" aria-label="Aisha Onola — main website">Aisha Onola</a>
  <nav class="top-nav" aria-label="Primary">${topLinks}</nav>
  <a class="contact-link" href="https://aishaonola.me/#contact">${ICONS.mail}<span>Contact</span></a>
</header>
<nav class="tab-bar" aria-label="Primary">${tabLinks}</nav>`;
}

function footer() {
  return `<footer class="site-footer">
  <div class="footer-top">
    <p class="footer-name">Aisha Onola</p>
    <p class="footer-note">Personal essays, and The OffScript — a weekly explainer for young Nigerians, written and produced by her.</p>
  </div>
  <div class="footer-links">
    <a href="/personal/">Personal</a>
    <a href="/offscript/">The OffScript</a>
    <a href="/explore/">Explore</a>
    <a href="https://aishaonola.me/#contact">Get in touch</a>
  </div>
  <p class="footer-meta">© 2026 Aisha Onola · Lagos, Nigeria</p>
</footer>`;
}

function page({ active, body, bodyClass = '', ...meta }) {
  const routeSeo = {
    home: {
      title: 'Aisha Onola | Writer and Creator of The OffScript',
      description: 'Aisha Onola is a Nigerian writer in Lagos and the creator of The OffScript. Read her personal essays and reported stories about life in Nigeria.'
    },
    personal: {
      title: 'Personal Writing | Aisha Onola',
      description: 'Personal essays by Aisha Onola about identity, relationships, culture, work and figuring things out in public.'
    },
    offscript: {
      title: 'The OffScript | Aisha Onola',
      description: 'The OffScript is Aisha Onola’s collection of reported stories explaining the politics, money, technology and systems shaping everyday life in Nigeria.'
    },
    explore: {
      title: 'Explore the Writing | Aisha Onola',
      description: 'Follow the connections between Aisha Onola’s personal observations and reported stories about everyday life in Nigeria.'
    }
  };
  const resolvedMeta = meta.type === 'article'
    ? { ...meta, title: `${meta.title} | Aisha Onola` }
    : { ...meta, ...routeSeo[active] };
  return `${head(resolvedMeta)}<body id="top" class="${bodyClass}" data-route="${active}"><div class="grain" aria-hidden="true"></div>${nav(active)}<main id="main">${body}</main>${footer()}</body></html>`;
}

// ---------------------------------------------------------------------------
// Homepage
// ---------------------------------------------------------------------------
function homePage() {
  const dating = bySlug['so-i-started-dating-myself'];
  const people = bySlug['people-who-made-my-world'];
  const cement = bySlug['offscript-005-we-make-enough-cement-to-export-it-so-why-is-a-bag-still-13-000'];
  const ai = bySlug['offscript-004-nigeria-doesn-t-have-an-ai-problem-it-has-an-ownership-problem'];
  const nysc = bySlug['offscript-001-everyone-argued-about-a-uniform-they-missed-the-real-reform'];
  const chic = bySlug['it-kinda-chic-to-stay'];

  const strip = [people, cement, ai, nysc];

  const heroEntrance = `<section class="hero-entrance">
    <div class="hero-portrait"><img src="/images/aisha-onola.jpg" width="1122" height="1402" alt="Portrait of Aisha Onola" loading="eager" fetchpriority="high"></div>
    <div class="hero-copy">
      <p class="kicker">Personal essays &amp; The OffScript</p>
      <h1>Aisha Onola</h1>
      <p class="hero-intro">I write about the things that are easy to miss — a person who quietly changed how I see things, a headline that means more than it says. Some of it's personal. Some of it, I built a whole publication around.</p>
    </div>
  </section>`;

  const openingExcerpt = `<section class="opening-excerpt">
    <p class="opening-label">Begin here</p>
    <blockquote>“${escapeHtml(EXCERPTS['it-kinda-chic-to-stay'])}”</blockquote>
    <p class="opening-source">From <a href="${internal(chic)}">${escapeHtml(chic.title)}</a></p>
    <a class="text-link" href="${internal(chic)}">Keep reading ${ICONS.arrow}</a>
  </section>`;

  const feature = `<article class="entry-feature">
    <a class="entry-feature-media" href="${internal(dating)}" aria-hidden="true" tabindex="-1"><img src="${dating.cover}" alt="" loading="lazy"></a>
    <div class="entry-feature-copy">
      <p class="entry-kicker is-personal">Personal writing</p>
      <h2><a href="${internal(dating)}">${escapeHtml(dating.title)}</a></h2>
      <p class="entry-excerpt">“${escapeHtml(EXCERPTS['so-i-started-dating-myself'])}”</p>
      <a class="button button-ink" href="${internal(dating)}">Read the story ${ICONS.arrow}</a>
    </div>
  </article>`;

  const stripCards = strip.map((item) => `<article class="entry-card ${categoryClass(item)}">
    <a class="entry-card-media" href="${internal(item)}" tabindex="-1" aria-hidden="true"><img src="${item.cover}" alt="" loading="lazy"></a>
    <p class="entry-kicker">${item.kind === 'offscript' ? `Issue ${item.issueNumber}` : 'Personal'}</p>
    <h3><a href="${internal(item)}">${escapeHtml(item.title)}</a></h3>
    <p class="entry-card-excerpt">${escapeHtml(EXCERPTS[item.slug])}</p>
  </article>`).join('');

  const curated = `<section class="curated-entries">
    <div class="section-head"><p class="kicker">A few places to start</p><h2>Personal essays and OffScript stories, mixed on purpose.</h2></div>
    ${feature}
    <div class="entry-strip" data-scroll-strip>${stripCards}</div>
  </section>`;

  const routes = `<section class="collection-routes">
    <a class="route-tile" href="/personal/"><span class="route-tile-icon">${ICONS.personal}</span><span><strong>Personal</strong><em>${personal.length} essays and observations</em></span>${ICONS.arrow}</a>
    <a class="route-tile" href="/offscript/"><span class="route-tile-icon">${ICONS.offscript}</span><span><strong>The OffScript</strong><em>Five issues, chosen from the archive</em></span>${ICONS.arrow}</a>
    <a class="route-tile" href="/explore/"><span class="route-tile-icon">${ICONS.explore}</span><span><strong>Explore</strong><em>Follow a thought across both</em></span>${ICONS.arrow}</a>
  </section>`;

  const contactLine = `<section class="quiet-contact"><p>Working on something and think it's a fit? <a href="https://aishaonola.me/#contact">Get in touch</a>.</p></section>`;

  const body = `${heroEntrance}${openingExcerpt}${curated}${routes}${contactLine}`;
  const schema = { '@context': 'https://schema.org', '@type': 'WebSite', name: 'Aisha Onola — Writing', url: SITE_URL, author: { '@type': 'Person', name: 'Aisha Onola', url: 'https://aishaonola.me' } };
  return page({ active: 'home', title: 'Aisha Onola', description: 'Personal essays and The OffScript — reported stories about Nigeria, money, technology, and the systems beneath ordinary life, written by Aisha Onola.', pathname: '/', schema, bodyClass: 'home-page', body });
}

// ---------------------------------------------------------------------------
// Personal collection page
// ---------------------------------------------------------------------------
function personalPage() {
  const order = ['people-who-made-my-world', 'so-i-started-dating-myself', 'it-kinda-chic-to-stay', 'that-not-what-decentering-men'];
  const items = order.map((slug) => bySlug[slug]);
  const [people, dating, chic, decentering] = items;

  const block = (item, size, extra = '') => `<article class="essay-block essay-block--${size}">
    <a class="essay-media" href="${internal(item)}" tabindex="-1" aria-hidden="true"><img src="${item.cover}" alt="" loading="lazy"></a>
    <div class="essay-copy">
      <p class="essay-meta">${escapeHtml(formatDate(item.date))} · ${escapeHtml(item.publication)}</p>
      <h2><a href="${internal(item)}">${escapeHtml(item.title)}</a></h2>
      <p class="essay-excerpt">${escapeHtml(EXCERPTS[item.slug])}</p>
      ${extra}
      <a class="text-link" href="${internal(item)}">Read the essay ${ICONS.arrow}</a>
    </div>
  </article>`;

  const body = `<section class="collection-hero">
    <p class="kicker">Personal writing · ${personal.length} pieces</p>
    <h1>Personal</h1>
    <p class="collection-intro">Essays about the people, ideas, and ordinary days that shaped how I see things. Written the way I'd actually say them.</p>
  </section>
  <section class="essay-stack">
    ${block(people, 'medium')}
    ${block(dating, 'flagship')}
    ${block(chic, 'medium', '<p class="essay-tag">→ This is where The OffScript starts</p>')}
    ${block(decentering, 'compact')}
  </section>`;
  return page({ active: 'personal', title: 'Personal writing', description: `${personal.length} personal essays and observations by Aisha Onola.`, pathname: '/personal/', bodyClass: 'personal-page', body });
}

// ---------------------------------------------------------------------------
// The OffScript collection page
// ---------------------------------------------------------------------------
function offscriptPage() {
  const order = [
    'offscript-005-we-make-enough-cement-to-export-it-so-why-is-a-bag-still-13-000',
    'offscript-003-nigeria-is-quietly-having-one-of-its-best-years-internationally-here-s-why-you-still-don-t-feel-it',
    'offscript-004-nigeria-doesn-t-have-an-ai-problem-it-has-an-ownership-problem',
    'offscript-002-the-us-is-quietly-locking-nigerians-out',
    'offscript-001-everyone-argued-about-a-uniform-they-missed-the-real-reform'
  ];
  const items = order.map((slug) => bySlug[slug]);

  const issueBlock = (item, index) => `<article class="issue-block ${index === 0 ? 'issue-block--flagship' : ''}">
    <a class="issue-number" href="${internal(item)}" aria-hidden="true" tabindex="-1">${item.issueNumber}</a>
    <div class="issue-copy">
      <p class="issue-tag">${escapeHtml(EDITORIAL[item.slug]?.jobTag || 'The OffScript')}</p>
      <h2><a href="${internal(item)}">${escapeHtml(item.title)}</a></h2>
      <p class="issue-excerpt">${escapeHtml(EXCERPTS[item.slug])}</p>
      <a class="text-link" href="${internal(item)}">Read issue ${item.issueNumber} ${ICONS.arrow}</a>
    </div>
    <a class="issue-media" href="${internal(item)}" tabindex="-1" aria-hidden="true"><img src="${item.cover}" alt="" loading="lazy"></a>
  </article>`;

  const body = `<section class="collection-hero collection-hero--offscript">
    <p class="kicker">The OffScript</p>
    <h1>The OffScript</h1>
    <p class="collection-intro">Nigeria's headlines, followed past the announcement. I write and produce every issue myself. These five are a starting point, not the whole archive.</p>
  </section>
  <section class="issue-stack">
    ${items.map(issueBlock).join('')}
  </section>
  <p class="archive-nudge">Read every issue at <a href="https://theoffscript.page/">theoffscript.page ${ICONS.external}</a></p>`;
  return page({ active: 'offscript', title: 'The OffScript', description: `Five OffScript issues by Aisha Onola, with the full archive at theoffscript.page.`, pathname: '/offscript/', image: items[0].cover, bodyClass: 'offscript-page', body });
}

// ---------------------------------------------------------------------------
// Explore page — a trail, not a network diagram
// ---------------------------------------------------------------------------
function explorePage() {
  const themeCounts = new Map();
  writing.forEach((item) => item.topics.forEach((topic) => themeCounts.set(topic, (themeCounts.get(topic) || 0) + 1)));
  const themeOrder = ['Nigeria', 'Systems', 'Identity', 'Money', 'Technology', 'Everyday life', 'Work', 'Culture', 'Belonging', 'People', 'Internet feminism', 'Internet culture', 'Information', 'Self-knowledge', 'Housing', 'Ownership', 'Mobility', 'Education'];
  const themes = themeOrder.filter((theme) => themeCounts.has(theme));
  const initial = themes.includes('Identity') ? 'Identity' : themes[0];

  const pills = themes.map((theme) => `<button type="button" data-theme="${escapeHtml(theme.toLowerCase())}" aria-pressed="${theme === initial}">${escapeHtml(theme)}<small>${themeCounts.get(theme)}</small></button>`).join('');

  const trailItems = writing.map((item) => `<li class="trail-item ${categoryClass(item)}" data-trail-item data-topics="${escapeHtml(item.topics.join('|').toLowerCase())}">
    <a href="${internal(item)}">
      <span class="trail-kind">${item.kind === 'offscript' ? `Issue ${item.issueNumber}` : 'Personal'}</span>
      <h3>${escapeHtml(item.title)}</h3>
      <p>“${escapeHtml(EXCERPTS[item.slug])}”</p>
      <span class="trail-topics">${item.topics.map((topic) => `<em data-topic="${escapeHtml(topic.toLowerCase())}">${escapeHtml(topic)}</em>`).join('')}</span>
    </a>
  </li>`).join('');

  const descriptions = themes.map((theme) => `<p data-theme-desc="${escapeHtml(theme.toLowerCase())}"${theme === initial ? '' : ' hidden'}>${escapeHtml(TOPIC_DESC[theme.toLowerCase()] || '')}</p>`).join('');

  const body = `<section class="explore-hero">
    <p class="kicker">Explore · ${writing.length} pieces</p>
    <h1>Follow a thought.</h1>
    <p>Pick an idea. Everything carrying it lines up below — personal writing and OffScript stories, side by side.</p>
  </section>
  <section class="theme-picker-wrap">
    <div class="theme-picker" role="group" aria-label="Choose a recurring idea" data-scroll-strip>${pills}</div>
  </section>
  <section class="trail-wrap" data-trail data-initial-theme="${escapeHtml(initial.toLowerCase())}">
    <div class="trail-heading">
      <p>Following</p>
      <h2 data-theme-label>${escapeHtml(initial)}</h2>
      <div class="trail-desc">${descriptions}</div>
      <p class="trail-count" aria-live="polite"><span data-map-count></span> pieces</p>
    </div>
    <ol class="trail">${trailItems}</ol>
  </section>`;
  return page({ active: 'explore', title: 'Explore the ideas', description: `Follow recurring ideas across ${writing.length} pieces by Aisha Onola.`, pathname: '/explore/', bodyClass: 'explore-page', body });
}

// ---------------------------------------------------------------------------
// Article pages
// ---------------------------------------------------------------------------
function heroFor(item) {
  const cfg = EDITORIAL[item.slug] || {};
  const kicker = item.kind === 'offscript' ? `The OffScript · Issue ${item.issueNumber} · ${escapeHtml(cfg.jobTag || '')}` : 'Personal writing';
  const back = item.kind === 'offscript' ? '/offscript/' : '/personal/';
  const originalLabel = item.kind === 'offscript' ? 'The OffScript' : item.publication;
  const metaLine = `<time datetime="${item.date}">${escapeHtml(formatDate(item.date))}</time>${item.originalUrl ? `<span aria-hidden="true">·</span><a href="${escapeHtml(item.originalUrl)}">Originally on ${escapeHtml(originalLabel)} ${ICONS.external}</a>` : `<span aria-hidden="true">·</span><span>${escapeHtml(item.publication)}</span>`}`;
  return `<header class="article-hero article-hero--${cfg.family}">
    <a class="back-link" href="${back}">${ICONS.arrow.replace('i-arrow', 'i-arrow i-arrow-back')} Back</a>
    <p class="article-kicker">${kicker}</p>
    <h1>${escapeHtml(item.title)}</h1>
    <p class="article-subtitle">${escapeHtml(item.subtitle)}</p>
    <div class="article-meta">${metaLine}</div>
    <figure class="article-figure"><img src="${item.cover}" alt="${escapeHtml(item.kind === 'offscript' ? `Cover for The OffScript issue ${item.issueNumber}` : `Cover image for ${item.title}`)}" loading="eager"></figure>
  </header>`;
}

function connectionBlock(item) {
  const cfg = CONNECTIONS[item.slug];
  if (!cfg) return '';
  const target = bySlug[cfg.to];
  if (!target) return '';
  return `<section class="connection ${categoryClass(target)}">
    <p class="connection-kicker">${escapeHtml(cfg.kicker)}</p>
    <p class="connection-note">${escapeHtml(cfg.note)}</p>
    <a class="connection-card" href="${internal(target)}">
      <img src="${target.cover}" alt="" loading="lazy">
      <span>
        <em>${kindLabel(target)}</em>
        <strong>${escapeHtml(target.title)}</strong>
      </span>
      ${ICONS.arrow}
    </a>
  </section>`;
}

function behindPiece(item) {
  const notes = [];
  if (item.behindThePiece.note) notes.push(['Why I wrote this', item.behindThePiece.note]);
  if (item.behindThePiece.process) notes.push(['How I approached it', item.behindThePiece.process]);
  if (item.behindThePiece.extras?.length) notes.push(['Notes I kept', item.behindThePiece.extras]);
  if (!notes.length) return '';
  return `<section class="behind-piece" data-behind><button class="behind-toggle" type="button" aria-expanded="false" aria-controls="behind-${item.slug}"><span>Notes on this piece</span><i aria-hidden="true">+</i></button><div class="behind-drawer" id="behind-${item.slug}" hidden>${notes.map(([label, value]) => `<div><h3>${escapeHtml(label)}</h3>${Array.isArray(value) ? `<ul>${value.map((entry) => `<li>${escapeHtml(entry)}</li>`).join('')}</ul>` : `<p>${escapeHtml(value)}</p>`}</div>`).join('')}</div></section>`;
}

function articlePage(item) {
  const canonical = item.originalUrl || absolute(internal(item));
  const originalLabel = item.kind === 'offscript' ? 'The OffScript' : item.publication;
  const subscribe = item.kind === 'offscript'
    ? `<a class="button button-ink" href="${item.subscribeUrl}">Subscribe to The OffScript ${ICONS.external}</a><a class="text-link" href="/personal/">Explore personal writing ${ICONS.arrow}</a>`
    : `<a class="button button-ink" href="${item.subscribeUrl}">${item.publication === 'Medium' ? 'Follow on Medium' : 'Read on Substack'} ${ICONS.external}</a><a class="text-link" href="/offscript/">Explore The OffScript ${ICONS.arrow}</a>`;

  const body = `<div class="reading-progress" aria-hidden="true"><i></i></div>
  ${heroFor(item)}
  <div class="article-layout"><article class="article-body">${familyBodyHtml(item)}</article><aside class="article-aside"><p>${item.kind === 'offscript' ? `ISSUE ${item.issueNumber}` : 'PERSONAL'}</p><span>${escapeHtml(item.topics.join(' · '))}</span></aside></div>
  <div class="article-after">
    ${behindPiece(item)}
    ${item.originalUrl ? `<div class="original-cta"><p>Originally published in ${escapeHtml(originalLabel)}</p><a class="button button-line" href="${escapeHtml(item.originalUrl)}">Read the original ${ICONS.external}</a></div>` : ''}
    ${connectionBlock(item)}
    <section class="article-subscribe"><h2>${item.kind === 'offscript' ? 'Stay in tune.' : 'More personal writing?'}</h2><p>${item.kind === 'offscript' ? 'One weekly email explaining the stories shaping everyday life in Nigeria.' : 'Essays about identity, people, work, and figuring things out in public.'}</p><div class="subscribe-buttons">${subscribe}</div></section>
  </div>`;
  const schema = { '@context': 'https://schema.org', '@type': item.kind === 'offscript' ? 'NewsArticle' : 'Article', headline: item.title, description: item.subtitle, image: absolute(item.cover), datePublished: item.date, author: { '@type': 'Person', name: 'Aisha Onola', url: 'https://aishaonola.me' }, publisher: { '@type': 'Organization', name: item.publication }, mainEntityOfPage: canonical, isAccessibleForFree: true };
  return page({ active: item.kind === 'offscript' ? 'offscript' : 'personal', title: item.title, description: item.subtitle, pathname: internal(item), canonical, image: item.cover, type: 'article', schema, bodyClass: `article-page article-page--${(EDITORIAL[item.slug] || {}).family} ${categoryClass(item)}`, body });
}

// ---------------------------------------------------------------------------
// Build
// ---------------------------------------------------------------------------
fs.rmSync(dist, { recursive: true, force: true });
fs.mkdirSync(dist, { recursive: true });
copyDir(path.join(ROOT, 'public'), dist);

const routes = [
  ['index.html', homePage()],
  ['personal/index.html', personalPage()],
  ['offscript/index.html', offscriptPage()],
  ['explore/index.html', explorePage()]
];
for (const [relativePath, html] of routes) {
  const output = path.join(dist, relativePath);
  fs.mkdirSync(path.dirname(output), { recursive: true });
  fs.writeFileSync(output, html, 'utf8');
}
for (const item of writing) {
  const articleDir = path.join(dist, 'writing', item.slug);
  fs.mkdirSync(articleDir, { recursive: true });
  fs.writeFileSync(path.join(articleDir, 'index.html'), articlePage(item), 'utf8');
}
const sitemapPaths = ['/', '/personal/', '/offscript/', '/explore/', ...writing.map(internal)];
fs.writeFileSync(path.join(dist, 'sitemap.xml'), `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${sitemapPaths.map((pathname) => `  <url><loc>${absolute(pathname)}</loc></url>`).join('\n')}\n</urlset>\n`, 'utf8');
fs.writeFileSync(path.join(dist, 'robots.txt'), `User-agent: *\nAllow: /\nSitemap: ${SITE_URL}/sitemap.xml\n`, 'utf8');
console.log(`Built 4 collection routes + ${writing.length} internal article pages from ${personal.length} personal pieces and ${offscript.length} curated OffScript issues.`);
