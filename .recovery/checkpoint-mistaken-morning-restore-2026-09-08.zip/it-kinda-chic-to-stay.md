Title: "It’s Kinda Chic to Stay Informed"
Subtitle: "We have never had more access to information. We’ve also never been better at missing it."
date: "2026-09-02"
category: "Personal"
cover: "/writing/it-kinda-chic-to-stay-informed.jpeg"
publishedOn: "Substack"
originalUrl: https://aishaonola.substack.com/p/so-i-started-dating-myself
featured: False


.....

A few months ago, I asked some friends if they’d heard about Hantavirus.

The responses genuinely surprised me. One person thought I was talking about a new TikTok trend. Another had no idea what I was talking about.

I remember just thinking, how are we this online and still missing things?

Because we’re always online. We wake up and check our phones. We scroll X while eating. We open TikTok for five minutes and somehow it’s 40 minutes later. Stories, statuses, push notifications, trending topics, there’s always something trying to get our attention. Our phones probably know more about what we’re interested in than some of our friends do.

So how is it that you can spend six hours on your phone and still have no idea what’s happening outside the little corner of the internet you’ve been given?

Being online can really trick you into thinking you’re informed. You see something trending on X and think, oh yeah, I saw that. You watch a 45-second TikTok explaining something and suddenly you’re an expert. 😭 You look at your screen time, see six hours, and think, surely I picked up SOMETHING useful in all that time.

But did you?

And I don’t mean that in a “young people are lazy and don’t read the news” way. Young people are incredibly curious. We’re constantly asking questions, forming opinions, arguing about things online, sending each other screenshots, trying to figure out what’s going on.

The problem is there’s just so much information, and when there’s that much of it, it’s surprisingly easy to miss the things that actually matter. Your algorithm knows you want to see every celebrity breakup and every viral debate. It doesn’t know you should probably understand what’s happening with the economy, or public health, or a new government policy, or something happening halfway across the world that could eventually affect you. Those things don’t always go viral enough to reach your feed.

That’s the part that gets me. There’s a huge world outside our feeds, and I think we should know a little more about it.

That’s basically where The OffScript came from.

I wanted something for people somewhere between “I don’t have time to read the news every day” and “I don’t want to be the person who has no idea what’s happening.” So every week, The OffScript brings together the news and conversations worth knowing about, particularly for young Nigerians, and makes them easier to actually understand. Not just what happened, but why it matters.

Because sometimes you don’t need 50 headlines. You just need enough context to hear something on the radio, see a headline on X, walk into a conversation, or open a group chat, and go, “Ohhh. I know what’s going on.”

Maybe that’s a small thing. But I don’t think it is, especially now, when our phones give us access to practically everything and somehow make it easier than ever to miss what’s important.

So yeah. It’s kinda chic to stay informed. 💛

And apparently, that’s what I’m building now. If you’d like to be part of it, you can subscribe to The OffScript here: theoffscript.page