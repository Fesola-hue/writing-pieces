Title: "So, I started dating myself"
subtitle: "Turns out, it's hard to love someone you've never met"
date: "2026-09-01"
category: "Personal"
cover: "/writing/so-i-started-dating-myself.jpeg"
publishedOn: "Medium"
originalUrl: https://aishaonola.medium.com/so-i-started-dating-myself-0bbc50448a02
featured: True


......

I spent my teenage years trying to love myself, and every time I thought I had, it fell apart.

I watched the videos, read the books, listened to the audios, and yes, I even had a Spotify playlist that was just “bad bitch” and “boss bitch” songs. None of it worked. I’d love myself for a few days, then the feeling would crash without warning.

I believed that if I just recited it enough, or listened to it enough, I’d eventually love myself. So I did, every day, every hour, constantly. But I never actually did it, I just pretended and ran with it. And a few days later, I’d always end up exposing myself, because you can’t hide a hateful voice away forever.

After years of that, I finally stopped trying and started asking why. Why did it seem to work for everyone except me? Was I cursed? Was I just born hateful?

Neither. It never worked because I wasn’t actually trying to love myself, I was trying to pretend I did. I was trying to manifest my way into it, like it was something I was born with that I just had to invoke, the way everyone else seemed to.

So what was I missing? Here’s what I found: my entire life was a book written by everyone around me. They picked a thing about me and wrote down how I should live, feel, eat, drink, and carry myself. The pen, the paper, none of it was mine.

I was trying to earnestly love a version of myself I couldn’t understand or explain, because I hadn’t written it. That book was deciding how I should live, what I should like, and honestly, who I was, without ever asking me.

And the unfortunate part? It never grew with me.

So I decided to write my own book. I got my own blank page.

That part was hard. Starting from nothing usually is. I felt empty, sometimes losing the will to live, but I didn’t want to go back to a book that was never mine to begin with.

So I decided to date myself.

You know how you date someone you barely know, and get to know them through different experiences along the way? That’s exactly what I did.

It was fascinating, fun, and I had a reason to live. I’d write things in my journal like, “hey, I just found out Hayyi loves milk, haha,” genuinely excited to be learning myself in real time. Some of it was interesting. Some of it wasn’t.

I realised loving myself was never going to be linear, or 100%, and I started making peace with the days I didn’t feel it. Because it’s more about loving yourself even when it’s hard, slow, bad, or sad, not just on the good days. It’s being willing to be you even when the storm hits. Choosing yourself in the face of adversity. Loving you on the happiest days and, most importantly, writing different chapters for different versions of your life, in your own words, with your own pen.

Because life is however you define it, and your life is shaped by the books and lenses you use to live it.

If you’re going to live through a book anyway, you might as well have a hand in writing it.

And yes, you can’t manifest your way into it. The same way you never manifested your way into loving a partner. You just do, you just learn, you just practice.

Bye! 🫶